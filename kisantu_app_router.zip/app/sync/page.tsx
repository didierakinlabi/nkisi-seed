
export default function SyncPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-neutral-100 text-neutral-900">
      <h1 className="text-2xl font-bold">Sync Page</h1>
    </div>
  );
}
