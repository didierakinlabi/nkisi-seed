
# 🧵 Nkisi Memory Stitching Protocol (v1.0)

This document describes the logic for **multi-entry cloth memory blocks**, where partial entries are followed by new data within the same 16×16 tone grid.
...
