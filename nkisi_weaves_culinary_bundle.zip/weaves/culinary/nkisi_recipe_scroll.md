
# 🥣 Griot Family Culinary Scroll (Nkisi Format)

A growing encoded archive of family recipes, prepared as cloth memory blocks using the Nkisi Fractal Cypher System (NFCS).
...
